package com.example.devops.web;
import org.junit.jupiter.api.Test;
class HelloServletTest { @Test void dummy(){ assert true; } }
